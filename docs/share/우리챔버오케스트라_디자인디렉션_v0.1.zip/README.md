# 디자인 디렉션 공유 방법

## 파일 구성

```
docs/share/
├── design-direction.html   ← 메인 공유 문서 (브라우저에서 열기)
├── assets/
│   ├── goodwoori-ci.png
│   └── goodwoori-characters.png
└── README.md
```

## 공유 방법

### 1. 폴더 압축 후 전달 (권장)

`docs/share` 폴더 전체를 ZIP으로 압축해 이메일·카카오톡·구글드라이브로 보냅니다.

수신자는 ZIP을 풀고 **`design-direction.html`** 을 더블클릭하면 브라우저에서 바로 볼 수 있습니다.

### 2. PDF로 저장

1. `design-direction.html` 을 Chrome/Edge에서 엽니다.
2. `Ctrl + P` (인쇄)
3. 대상: **PDF로 저장**
4. PDF 파일을 공유합니다.

### 3. 사이트 배포 후 URL 공유 (개발 후)

홈페이지가 배포되면 `https://도메인/design-direction` 형태로 올려 링크만 공유할 수 있습니다.

## 로컬에서 미리보기

Windows 탐색기에서 아래 파일을 더블클릭:

```
C:\Users\gram\wco_web\docs\share\design-direction.html
```
